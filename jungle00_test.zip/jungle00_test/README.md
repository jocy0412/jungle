# jungle00

작업 범위 

db에 들어올 key 값

- user
  - 아이디
  - 비밀번호

- shop
  - 가게명
    - url: /api/shop
    - 변수이름: shop_name
  - 가게주소
    - url: /api/shop
    - 변수이름: shop_address
  - 가게 이미지 URL or 파일
    - url: /api/shop
    - 변수이름: shop_img
  - 가게 네이버 지도 url
    - 변수이름: shop_url
  - 음식카테고리
    - url: /api/food
    - 변수이름: food_category
  - 음식명
    - url: /api/food
    - 변수이름: food_name
  - 좋아요 갯수
    - url: /api/like
    - 변수이름 : like
  - 싫어요 갯수 
    - url: /api/hate
    - 변수이름 : hate
  - 푸드코드
    - 변수이름: food_code