from flask import *
from pymongo import MongoClient
import hashlib
from datetime import *
import jwt

app = Flask(import_name = __name__)

client = MongoClient('mongodb://test:test@54.180.139.22', 27017)  # mongoDB는 27017 포트로 돌아갑니다.
db = client.dbmuckji  # 'dbmuckji'라는 이름의 db를 만들거나 사용합니다.

app.secret_key = "Jungle"

@app.route("/")
def home():
	return render_template('test.html')

# id, pw 를 받아서, mongoDB에 저장
# 저장하기 전에, pw를 sha256 방법(= 단방향 암호화. 풀어볼 수 없음)으로 암호화 해서 저장한다.
@app.route("/api/register", methods=["POST"])
def api_register():
    username_receive = request.form['username_give']  
    id_receive = request.form['id_give']
    pw_receive = request.form['pw_give']
    pw_hash = hashlib.sha256(pw_receive.encode('utf-8')).hexdigest()
	
    userinfo = {
                'username' : username_receive,
                'id' : id_receive,
                'password' : pw_hash
            }

    db.users.insert_one(userinfo)

    return jsonify({'result': 'success','msg':'회원가입 완료!'})
	
@app.route('/api/login', methods=['POST'])
def api_login():
    id_receive = request.form['id_give']
    pw_receive = request.form['pw_give']
    # 비밀번호 hash화 시키기
    pw_hash = hashlib.sha256(pw_receive.encode('utf-8')).hexdigest()

	#id, 암호화된 pw를 가지고 해당 유저 찾기
    result = db.users.find_one({'id': id_receive, 'password': pw_hash})

    #pw는 해쉬화 시킨 후 db속에 일치하는 데이터가 존재하면 result로 담아온다
    if result is not None:
        payload = {
            'id': id_receive,
            'exp': datetime.utcnow() + timedelta(seconds=3600)  # 로그인 24시간 유지
        }
        token = jwt.encode(payload, app.secret_key , algorithm='HS256')
        #test
        return jsonify({'result': 'success', 'token': token})
    else :
        return jsonify({'result': 'fail', 'msg': '아이디/비밀번호가 일치하지 않습니다'})

if __name__ == '__main__':
	app.run(host = '0.0.0.0',
					port = 5000, 
					debug = True)